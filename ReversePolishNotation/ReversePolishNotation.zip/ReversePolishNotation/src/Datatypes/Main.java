// Enter what is to be calculated
// 11 12 + 15 10 - * =
// You have entered: 11 12 + 15 10 - * =
// You got: 115.0


package Datatypes;

import java.util.Scanner;

public class Main {
	
	double number1;
	double number2;
	double sum;

   
	public static void main(String[] args) {
				Main calc = new Main();
				Scanner userObj = new Scanner(System.in);
				IDatatypes stack;
				
				while(true) {
					stack = new Stack();
					System.out.println("Enter what is to be calculated");
	
					String userInput = userObj.nextLine();
					System.out.println("You have entered: " + userInput);
					
					if (userInput.isEmpty()){
						System.out.println("You have not entered anything");
					} else {
						calc.calculate(userInput, stack);	
					}
				}
	}
	
	private void calculate(String userInput, IDatatypes stack) {
		for(String i : userInput.split(" ")) {
			if(i.equals("+") || i.equals("-") || i.equals("*") || i.equals("/") || i.contentEquals("="))
		     {
				switch (i) 
		          {
		                case "+":
		                    number1 = stack.pop();
		                    number2 = stack.pop();
		                    sum = number1 + number2;
		                    stack.push(sum);
		                    break;
		                case "-":
		                    number1 = stack.pop();
		                    number2 = stack.pop();
		                    sum = number2 - number1; // Switched because pop order
		                    stack.push(sum);
		                    break;
		                case "/":
		                    number1 = stack.pop();
		                    number2 = stack.pop();
		                    sum = number1 / number2;
		                    stack.push(sum);
		                    break;
		                case "*":
		                    number1 = stack.pop();
		                    number2 = stack.pop();
		                    sum = number2 * number1;
		                    stack.push(sum);
		                    break;
		                case "=":
		                	number1 = stack.pop();
		                	number2 = stack.pop();
		                	sum = number1 + number2;
			                stack.push(sum);
		                	double number3 = number1 + number2;
		                	System.out.println("You got: " + number3);
		                	break;
		            }
		         }
		         else{
		                 stack.push(Double.parseDouble(i));
		         }				
			}
	}
				

}
