package Datatypes;

public interface IDatatypes {
	
	public boolean is_empty();
	
	public void push(double x);
	
	public double pop();

}
